var assert = require('chai').assert;
var sinon = require('sinon');
var proxyquire = require('proxyquire').noCallThru().noPreserveCache();

class Money {
    constructor(a) {
        this.a = a;
    }

    getDecimalValue() {
        return this.a;
    }
}

var iteratorEmptyMock = {
    iterator: function () {
        return {
            hasNext: function () { return false; }
        };
    }
};

var zeroValue = {
    value: 0,
    getDecimalValue: function () {
        return 0;
    }
};

var orderMock = {
    currentOrderNo: '123',
    customerNo: '000',
    creationDate: '1/1/2020',
    createdBy: 'Bob',
    customerEmail: 'test@test.com',
    shipments: [{
        shippingMethodID: '001',
        shippingAddress: {
            firstName: 'Bob',
            lastName: 'Smith',
            address1: '123 test',
            address2: '',
            city: 'st louis',
            stateCode: 'mo',
            postalCode: '63144',
            countryCode: {
                value: {
                    toString: function () {
                        return 'US';
                    }
                }
            },
            phone: '123-123-1234',
            salutation: 'Mr',
            companyName: 'Acme',
            suffix: 'Jr'
        },
        shippingTotalNetPrice: zeroValue,
        shippingTotalGrossPrice: zeroValue,
        adjustedShippingTotalNetPrice: zeroValue,
        adjustedShippingTotalGrossPrice: zeroValue,
        adjustedShippingTotalTax: zeroValue,
        shipmentNo: ''
    }],
    billingAddress: {
        firstName: 'Bob',
        lastName: 'Smith',
        address1: '123 test',
        address2: '',
        city: 'st louis',
        stateCode: 'mo',
        postalCode: '63144',
        countryCode: {
            value: {
                toString: function () {
                    return 'US';
                }
            }
        },
        phone: '123-123-1234',
        salutation: 'Mr',
        companyName: 'Acme',
        suffix: 'Jr'
    },
    merchandizeTotalNetPrice: zeroValue,
    merchandizeTotalGrossPrice: zeroValue,
    adjustedMerchandizeTotalNetPrice: zeroValue,
    adjustedMerchandizeTotalGrossPrice: zeroValue,
    giftCertificateTotalNetPrice: zeroValue,
    giftCertificateTotalGrossPrice: zeroValue,
    shippingTotalNetPrice: zeroValue,
    shippingTotalGrossPrice: zeroValue,
    adjustedShippingTotalNetPrice: zeroValue,
    adjustedShippingTotalGrossPrice: zeroValue,
    adjustedShippingTotalTax: zeroValue,
    totalNetPrice: zeroValue,
    totalGrossPrice: zeroValue,
    customerLocaleID: 'en-US',
    remoteHost: '0.0.0.0',
    giftCertificateLineItems: iteratorEmptyMock,
    allShippingPriceAdjustments: iteratorEmptyMock,
    getPaymentInstruments: function () {
        return iteratorEmptyMock;
    },
    getAllProductLineItems: function () {
        return iteratorEmptyMock;
    },
    setExportStatus: function () {
    },
    custom: {
        deckCommerceExportCount: 0
    },
    defaultShipment: {
        giftMessage: ''
    }
};

var SiteMock = {
    getCurrent: function () {
        return {
            getCustomPreferenceValue: function (s) {
                if (s === 'DeckCommercePaymentMappings') {
                    return '{}';
                }

                return '';
            },
            getDefaultCurrency: function () {
                return 'USD';
            }
        };
    }
};

var LoggerInstanceMock = {
    error: function () {
    },
    info: function () {
    }
};
var LoggerMock = {
    getLogger: function () {
        return LoggerInstanceMock;
    }
};
var exportApiStub = sinon.stub();
var OrderExportMock = {
    ServiceExport: {
        call: function () {
            exportApiStub();
            return {
                ok: true
            };
        }
    }
};

var orderExportRequest = proxyquire('../../../../../../cartridges/int_deckcommerce_sfra/cartridge/scripts/service/request/orderExportRequest', {
    '*/cartridge/scripts/util/formatting': {
        formatCurrency: function (a) {
            return a;
        }
    },
    'dw/system/Site': SiteMock,
    'dw/system/Logger': LoggerMock,
    '*/cartridge/scripts/service/common/OrderExportHttpService': OrderExportMock,
    'dw/util/ArrayList': sinon.stub(),
    'dw/value/Money': Money,
    '*/cartridge/scripts/service/common/deckCommon': {
        getVerificationKey: function () {
            return '';
        }
    },
    'dw/order/Order': {
        EXPORT_STATUS_FAILED: 0,
        EXPORT_STATUS_EXPORTED: 1
    },
    'dw/campaign/Promotion': {
        PROMOTION_CLASS_ORDER: 0
    }
});


describe('orderExportRequest', function () {
    describe('exportOrder', function () {
        it('exportOrder should run without exception and should trigger API for order history to be called', function () {
            orderExportRequest.exportOrder(orderMock);
            assert.isTrue(exportApiStub.called);
        });
    });
});
