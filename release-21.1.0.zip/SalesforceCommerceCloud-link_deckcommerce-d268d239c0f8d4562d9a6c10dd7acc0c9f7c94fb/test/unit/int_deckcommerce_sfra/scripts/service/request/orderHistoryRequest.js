var assert = require('chai').assert;
var sinon = require('sinon');
var proxyquire = require('proxyquire').noCallThru().noPreserveCache();
var SiteMock = {
};
var LoggerInstanceMock = {
    error: function () {
    }
};
var LoggerMock = {
    getLogger: function () {
        return LoggerInstanceMock;
    }
};
var historyApiStub = sinon.stub();
var OrderHistoryMock = {
    ServiceExport: {
        call: function () {
            historyApiStub();
            return {
                ok: false
            };
        }
    }
};

var orderHistoryRequest = proxyquire('../../../../../../cartridges/int_deckcommerce_sfra/cartridge/scripts/service/request/orderHistoryRequest', {
    '*/cartridge/scripts/util/formatting': {
        formatCurrency: function (a) {
            return a;
        }
    },
    'dw/system/Site': SiteMock,
    'dw/system/Logger': LoggerMock,
    '*/cartridge/scripts/service/common/OrderHistoryHttpService': OrderHistoryMock,
    'dw/util/ArrayList': sinon.stub()
});


describe('orderHistoryRequest', function () {
    describe('getOrderHistory', function () {
        it('getOrderHistory should run without exception and should trigger API for order history to be called', function () {
            orderHistoryRequest.getOrderHistory('123', '63122', false, 'smith', 'CUST001', false, 'USD', null);
            assert.isTrue(historyApiStub.called);
        });
    });
});
