var assert = require('chai').assert;
var sinon = require('sinon');
var proxyquire = require('proxyquire').noCallThru().noPreserveCache();
var iteratorCounter = 0;
var OrderMgrMock = {
    searchOrders: function () {
        return {
            hasNext: function () {
                if (iteratorCounter === 0) {
                    iteratorCounter = 1;
                    return true;
                }
                return false;
            },
            next: function () {
                return { order: '123' };
            },
            close: function () {
            }
        };
    }
};
var SiteMock = {
};
var exportStub = sinon.stub();
var ExportMock = {
    exportOrder: exportStub
};
var LoggerInstanceMock = {
    error: function () {
    }
};
var LoggerMock = {
    getLogger: function () {
        return LoggerInstanceMock;
    }
};
var OrderMock = {
    EXPORT_STATUS_FAILED: 1,
    EXPORT_STATUS_READY: 2
};

var reExportOrderJob = proxyquire('../../../../../cartridges/int_deckcommerce_sfra/cartridge/scripts/jobs/reExportOrderJob', {
    'dw/order/OrderMgr': OrderMgrMock,
    'dw/system/Site': SiteMock,
    'dw/system/Logger': LoggerMock,
    'dw/order/Order': OrderMock,
    '*/cartridge/scripts/service/request/orderExportRequest': ExportMock
});


describe('reExportOrderJob', function () {
    describe('ExportReadyOrders', function () {
        it('reExportOrderJob should run without exception and should trigger export to be called', function () {
            reExportOrderJob.exportReadyOrders();
            assert.isTrue(exportStub.called);
        });
    });
});
