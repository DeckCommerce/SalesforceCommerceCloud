var Logger = require('dw/system/Logger').getLogger('DeckJobError', 'OrderExportJob');
var OrderMgr = require('dw/order/OrderMgr');
var EXPORT_STATUS_FAILED = require('dw/order/Order').EXPORT_STATUS_FAILED;
var EXPORT_STATUS_READY = require('dw/order/Order').EXPORT_STATUS_READY;
var Site = require('dw/system/Site');

/**
 * Worker function called by each of the two jobs to handle exporting orders.
 * @param {dw.order.Order} order - Order being exported
 */
function exportOrder(order) {
    try {
        var OrderExportAPI = require('*/cartridge/scripts/service/request/orderExportRequest');
        OrderExportAPI.exportOrder(order);
    } catch (error) {
        var err = error;
        Logger.error('DC Order Export Job - exception: ' + err.message + err.stack);
        throw error;
    }
}

/**
 * Gets a list of orders with a status of EXPORT_STATUS_FAILED, and will try to re-export these
 * to Deck Commerce. Note that there are site preferences that control how many times we will
 * retry the export, as well as how long we will try for.
 */
function exportFailedOrders() {
    try {
        var dateToCheck = new Date(new Date().setHours(new Date().getHours() - Site.getCurrent().getCustomPreferenceValue('deckCommerceMaxHourAgeToExport')));
        var maxAttempts = Site.getCurrent().getCustomPreferenceValue('deckCommerceMaxExportAttempts');

        var orders = OrderMgr.searchOrders('exportStatus={0} AND custom.deckCommerceLastExport>{1} AND (custom.deckCommerceExportCount = NULL OR custom.deckCommerceExportCount<{2})',
            'creationDate asc',
            EXPORT_STATUS_FAILED,
            dateToCheck,
            maxAttempts);

        while (orders.hasNext()) {
            exportOrder(orders.next());
        }
        orders.close();
    } catch (error) {
        var err = error;
        Logger.error('DC Order Export Job - exception: ' + err.message + err.stack);
        throw error;
    }
}

/**
 * Export any order with a status of EXPORT_STATUS_READY. Note that normally this
 * should not be needed, as orders should export in real-time. But this is used
 * to catch any orders that get past that for whatever reason, as well as any orders
 * which are manually changed back to this status in Business Manager.
 */
function exportReadyOrders() {
    try {
        var orders = OrderMgr.searchOrders('exportStatus = {0}',
            'creationDate asc',
            EXPORT_STATUS_READY,
            new Date()
            );

        while (orders.hasNext()) {
            exportOrder(orders.next());
        }
        orders.close();
    } catch (error) {
        var err = error;
        Logger.error('DC Order Export Job - exception: ' + err.message + err.stack);
        throw error;
    }
}

exports.exportFailedOrders = exportFailedOrders;
exports.exportReadyOrders = exportReadyOrders;
