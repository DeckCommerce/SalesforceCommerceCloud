/**
 * Initialize HTTP service for a Order History
 */

var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');
var Site = require('dw/system/Site');
/**
*
* Order Export HTTP Service
*
*/
exports.ServiceExport = LocalServiceRegistry.createService('deckcommerce.http.orderimport.post', {
    createRequest: function (svc, jsonOrderRequest) {
        var request = jsonOrderRequest;
        var apiBaseUrl = Site.getCurrent().getCustomPreferenceValue('DeckCommerceAPIbaseURL');
        var credentials = svc.configuration.credential;
        var url = credentials.URL;
        if ((apiBaseUrl) && url.toLowerCase().indexOf(apiBaseUrl.toLowerCase()) === -1) {
            // If the base URL doesn't match the start of the service URL, update it
            var indexPosition = url.toLowerCase().indexOf('/', 10);	// find slash (after https://)
            url = apiBaseUrl + url.substr(indexPosition + 1);
        }
        svc.setURL(url);

        svc.addHeader('Content-Type', 'application/json');
        svc.setRequestMethod('POST');
        svc.setEncoding('UTF-8');
        return request;
    },
    parseResponse: function (svc, client) {
        var responseText = '';
        if (client.text != null) {
            responseText = JSON.parse(client.text);
        } else {
            responseText = JSON.parse(client.errorText);
        }
        return responseText;
    },
    mockExec: function (svc, client) {
        return {
            statusCode: 200,
            statusMessage: 'OK',
            text: 'mock response' + client.text,
            timeout: 30000
        };
    },
    filterLogMessage: function (msg) {
        return msg;
    },
    getRequestLogMessage: function () {
        return null;
    },
    getResponseLogMessage: function () {
        return null;
    }
});

