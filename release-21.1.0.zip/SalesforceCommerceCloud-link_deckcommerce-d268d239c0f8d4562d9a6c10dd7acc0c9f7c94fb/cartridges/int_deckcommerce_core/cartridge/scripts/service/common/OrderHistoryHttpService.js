/**
 * Initialize HTTP service for a Order History
 */

var DeckHelper = require('*/cartridge/scripts/service/common/deckCommon');
var Logger = require('dw/system/Logger').getLogger('Deck');
var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');
var Site = require('dw/system/Site');
/**
*
* Order History HTTP Service
*
*/
exports.ServiceExport = LocalServiceRegistry.createService('deckcommerce.http.orderhistory.post', {
    createRequest: function (svc, OrderNumber, CustomerNumber, pageSize, pageNumber) {
        var siteCode = Site.getCurrent().getCustomPreferenceValue('DeckCommerceCompanyCode');
        var sharedKey = Site.getCurrent().getCustomPreferenceValue('DeckCommerceSharedApiKey');
        var apiVersion = Site.getCurrent().getCustomPreferenceValue('deckCommerceOrderHistoryVersion');
        var apiBaseUrl = Site.getCurrent().getCustomPreferenceValue('DeckCommerceAPIbaseURL');
        var timestamp = new Date().toUTCString();
        var verificationKey = DeckHelper.getVerificationKey(timestamp, DeckHelper.orderHistoryApiPart, sharedKey);
        var omsRequest = {
            SiteCode: siteCode,
            VerificationKey: verificationKey,
            TimestampUTC: timestamp,
            PageSize: pageSize,
            PageNumber: pageNumber
        };
        if ((OrderNumber) && OrderNumber.length > 0) {
            omsRequest.OrderNumber = OrderNumber;
        } else {
            omsRequest.CustomerID = CustomerNumber;
        }

        var request = JSON.stringify(omsRequest);
        Logger.info('Order History Request: ' + request);
        var credentials = svc.configuration.credential;
        var url = credentials.URL;
        if ((apiBaseUrl) && url.toLowerCase().indexOf(apiBaseUrl.toLowerCase()) === -1) {
            // If the base URL doesn't match the start of the service URL, update it
            var indexPosition = url.toLowerCase().indexOf('/', 10);	// find slash (after https://)
            url = apiBaseUrl + url.substr(indexPosition + 1);
        }
        svc.setURL(url);
        svc.addHeader('Content-Type', 'application/json');
        svc.addHeader('Authorization', 'Basic');
        svc.addHeader('apiVersion', apiVersion);
        svc.setRequestMethod('POST');
        svc.setEncoding('UTF-8');
        return request;
    },
    parseResponse: function (svc, client) {
        var responseText = '';
        if (client.text != null) {
            responseText = JSON.parse(client.text);
        } else {
            responseText = JSON.parse(client.errorText);
        }
        return responseText;
    },
    mockExec: function (svc, client) {
        return {
            statusCode: 200,
            statusMessage: 'OK',
            text: '{"OrderDetails":[{"EmailAddress":"jeff.tucker@deckis.com","GiftMessage":null,"OrderNumber":"00000801","OrderStatus":"Invalid","OrderDate":"2/14/2016 12:47:48 PM","OrderStatusCode":null,"ShippingMethod":"","CustomerID":"00004001","ShippingMethodID":-1,"Shipments":[],"CustomerAddress":{"ID":1,"IsChanged":false,"FirstName":"Jeff","PhoneticFirstName":null,"LastName":"Tucker","PhoneticLastName":null,"Address1":"1750 S. Brentwood","Address2":"Suite 209","Address3":null,"City":"Brentwood","Province":"MO","PostalCode":"63144","Country":"USA","Email":"jeff.tucker@deckis.com","Phone":"3149684152","MobilePhone":null,"CompanyName":null,"Salutation":null,"Suffix":null,"AddressLookUps":[{"Name":"White Pages","Url":"http://www.whitepages.com/search/ReverseAddress?street=1750+S.+Brentwood&where=63144"}],"PhoneLookUps":[{"Name":"Residential","Url":"http://www.whitepages.com/search/ReversePhone?full_phone=3149684152"},{"Name":"Business","Url":"http://www.yellowpages.com/phone/3149684152"}]},"ShipAddress":{"ID":2,"IsChanged":false,"FirstName":"Jeff","PhoneticFirstName":null,"LastName":"Tucker","PhoneticLastName":null,"Address1":"1750 S. Brentwood","Address2":"Suite 209","Address3":null,"City":"Brentwood","Province":"MO","PostalCode":"63144","Country":"USA","Email":"jeff.tucker@deckis.com","Phone":"3149684152","MobilePhone":null,"CompanyName":null,"Salutation":null,"Suffix":null,"AddressLookUps":[{"Name":"White Pages","Url":"http://www.whitepages.com/search/ReverseAddress?street=1750+S.+Brentwood&where=63144"}],"PhoneLookUps":[{"Name":"Residential","Url":"http://www.whitepages.com/search/ReversePhone?full_phone=3149684152"},{"Name":"Business","Url":"http://www.yellowpages.com/phone/3149684152"}]},"Items":[{"ExternalItemID":null,"ItemStatusName":"New","ItemStatusCode":"IN","Extended":[],"GTIN":"013742003048","DeckSKU":"013742003048","StyleNumber":null,"ProductSize":"","Attribute":"","Custom1":"","Custom2":null,"Custom3":null,"Custom4":"","Custom5":null,"ImageURL":null,"ItemTypeID":3,"ID":1,"Quantity":1,"DisplayPrice":38.0000,"DisplayDiscount":0.0}],"Totals":{"MerchandiseNetTotal":38.0000,"MerchandiseGrossTotal":39.9000,"AdjustedMerchandiseNetTotal":38.0000,"AdjustedMerchandiseGrossTotal":39.9000,"ShippingNetTotal":15.9900,"ShippingGrossTotal":16.7900,"AdjustedShippingNetTotal":15.9900,"AdjustedShippingGrossTotal":16.7900,"TotalNetTotal":53.9900,"TotalGrossTotal":56.6900,"IsChanged":false},"SimpleTotals":{"SubTotal":38.0000,"OriginalShipping":15.9900,"Shipping":15.9900,"Discount":0.0,"Tax":2.7000,"Total":56.6900},"Payments":[{"PaymentName":"Visa","Amount":56.6900}]}],"ResponseCode":0,"Message":""}',
            timeout: 30000,
            clientText: client.text
        };
    },
    filterLogMessage: function (msg) {
        return msg;
    },
    getRequestLogMessage: function () {
        return null;
    },
    getResponseLogMessage: function () {
        return null;
    }
});
