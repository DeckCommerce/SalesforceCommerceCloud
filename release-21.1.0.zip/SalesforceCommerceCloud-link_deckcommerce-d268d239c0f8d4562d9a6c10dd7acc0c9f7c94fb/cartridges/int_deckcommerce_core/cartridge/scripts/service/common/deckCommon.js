var Logger = require('dw/system/Logger').getLogger('Deck');
var messageDigest = require('dw/crypto/MessageDigest');
var DIGEST_SHA_256 = require('dw/crypto/MessageDigest').DIGEST_SHA_256;
var Encoding = require('dw/crypto/Encoding');
var Bytes = require('dw/util/Bytes');
var Site = require('dw/system/Site');
/**
 * Helper function to compute verification key used by Deck Commerce APIs. Relies on each side
 * having a shared key, which is used to compute a hash along with a timestamp.
 * @param {string} date - String version of date for verification key
 * @param {string} methodName - method name used for verification key
 * @param {string} sharedAPIKey - shared key used when computing verification key
 * @returns {string} Returns the computed verification key
*/
function getVerificationKey(date, methodName, sharedAPIKey) {
    try {
        var stringToHash = methodName + date + sharedAPIKey;
        var sha = messageDigest(DIGEST_SHA_256);
        var encodedKey = Encoding.toHex(sha.digestBytes(new Bytes(stringToHash)));
        return encodedKey;
    } catch (error) {
        Logger.error('DC Order Import - exception in getVerificationKey: ' + error);
        throw error;
    }
}

/**
 * Helper function to help generate pseudo GUID string
 * @returns {string} Partial string
 */
function s4() {
    return Math.floor((1 + Math.random()) * 0x10000)
      .toString(16)
      .substring(1);
}

/**
 * Create a pseudo GUID type string to be used as unique ID when passing queue messages to OMS. This ID
 * is used for tracking purposes only, and absolute uniqueness is not required.
 * @returns {string} Random pseudo GUID string
 */
function guid() {
    return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
    s4() + '-' + s4() + s4() + s4();
}

exports.guid = guid;
exports.getVerificationKey = getVerificationKey;
exports.sitePrefs = Site.getCurrent().getPreferences();
exports.omsApiPart = 'api/omsinboundorder';
exports.orderHistoryApiPart = 'api/omsorderhistory';
