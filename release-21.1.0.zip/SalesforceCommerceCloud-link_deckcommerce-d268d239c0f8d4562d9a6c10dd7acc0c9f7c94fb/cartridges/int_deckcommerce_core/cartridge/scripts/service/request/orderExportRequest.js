/**
* This script sends an order to the Deck Commerce order import API, using a message queue as
* the communication channel.
*/

/* eslint no-param-reassign: ["error", { "props": true, "ignorePropertyModificationsFor": ["dwOrder"] }] */

var DeckHelper = require('*/cartridge/scripts/service/common/deckCommon');
var Site = require('dw/system/Site');
var DeckOrderExportHelper = require('*/cartridge/scripts/service/common/OrderExportHttpService');
var Logger = require('dw/system/Logger').getLogger('Deck', 'OrderExport');
var EXPORT_STATUS_FAILED = require('dw/order/Order').EXPORT_STATUS_FAILED;
var EXPORT_STATUS_EXPORTED = require('dw/order/Order').EXPORT_STATUS_EXPORTED;
var PROMOTION_CLASS_ORDER = require('dw/campaign/Promotion').PROMOTION_CLASS_ORDER;

// Shipment gift message
var giftMessage;

/**
 * Helper function for handling failed exports
 * @param {dw.order.Order} dwOrder - Order being exported
*/
function handleFailedExport(dwOrder) {
    dwOrder.setExportStatus(EXPORT_STATUS_FAILED);

    // Increase export count so we can track number of failures
    dwOrder.custom.deckCommerceExportCount++;
}

/**
 * Helper function for ensuring all decimals have correct number of decimal places
 * @param {Numeric} decimalValue - Value to be converted
 * @returns {Numeric} Converted value
*/
function getCurrency(decimalValue) {
    try {
        var decimalNumber = Number(decimalValue.toFixed(4));
        var currencyPrecision = 2;
        var precisionFactor = Math.pow(10, currencyPrecision);
        return Math.round(decimalNumber * precisionFactor) / precisionFactor;
    } catch (e) {
        var err = e;
        Logger.error('DC Order Export - exception: ' + err.message + err.stack);
        throw e;
    }
}

/**
 * Gets a list of all shipping methods on this order (looking across all
 * shipments). Generates format needed by OMS import to accept multiple
 * shipping methods per order.
 * @param {dw.order.Order} order - Order being exported
 * @returns {Object} JSON object of shipping methods for this order as needed by OMS
 */
function getShippingMethods(order) {
    var data = [];
    for (var i = 0; i < order.shipments.length; i++) {
        var shippingMethodValue = '';
        if ((order.shipments[i].shippingMethodID)) {
            shippingMethodValue = order.shipments[i].shippingMethodID;
        } else if (order.giftCertificateLineItems.size() > 0) {
            shippingMethodValue = 'GiftCard';
        } else {
            shippingMethodValue = null;
        }

        data.push({
            ReferenceID: i,
            DwShipmentNo: order.shipments[i].shipmentNo,
            NetTotal: getCurrency(order.shipments[i].shippingTotalNetPrice.value).toString(),
            GrossTotal: getCurrency(order.shipments[i].shippingTotalGrossPrice.value).toString(),
            AdjustedNetTotal: getCurrency(order.shipments[i].adjustedShippingTotalNetPrice.value).toString(),
            AdjustedGrossTotal: getCurrency(order.shipments[i].adjustedShippingTotalGrossPrice.value).toString(),
            Taxes: [
                {
                    Amount: getCurrency(order.shipments[i].adjustedShippingTotalTax.value).toString(),
                    TaxType: 'USShippingTotal'
                }
            ],
            ShippingMethod: shippingMethodValue
        });
    }
    return data;
}

/**
 * Helper function to get the appropriate shipping reference ID for an item, given
 * the shipment number identifier.
 * @param {Array} shippingMethods - Shipping methods array
 * @param {string} shipmentNo - Shipment number to match on
 * @returns {string} Shipping reference ID
 */
function getShippingReferenceId(shippingMethods, shipmentNo) {
    for (var i = 0; i < shippingMethods.length; i++) {
        if (shippingMethods[i].DwShipmentNo === shipmentNo) {
            return shippingMethods[i].ReferenceID;
        }
    }

    return 0;
}

/**
 * Get order level taxes (typically shipping taxes)
 * @param {dw.order.Order} order - The order being exported
 * @returns {Object} JSON object representing the order taxes to be passed to OMS
*/
function getOrderTaxes(order) {
    try {
        return [{
            TaxType: 'USShippingTotal',
            Amount: getCurrency(order.adjustedShippingTotalTax.value).toString()
        }];
    } catch (error) {
        Logger.error('DC Order Import - exception in getOrderTaxes: ' + error.message + error.stack);
        throw error;
    }
}

/**
 * Used when adding pro-rated item discounts, to make sure we don't
 * double up actual item level discounts.
 * @param {Object} omsAdjustments - Order adjustment collection
 * @param {string} campaignID - Campaign ID being matched
 * @param {string} promotionID - Promotion ID being matched
 * @returns {number} Array index of matching campaign, or -1 if not found
*/
function doesCampaignAlreadyExist(omsAdjustments, campaignID, promotionID) {
    for (var i = 0; i < omsAdjustments.length; i++) {
        if (omsAdjustments[i].CampaignID === campaignID &&
            omsAdjustments[i].PromotionID === promotionID) {
            return i;
        }
    }
    return -1;
}

/**
 * getProductAttributeDisplayValue return product attribute display value.
 *
 * @param {dw.catalog.Product} product - The product object for a given order line item
 * @param {string} attributeID - The attribute ID that we want to get the value for
 * @returns {string} Attribute value
 **/
function getProductAttributeValue(product, attributeID) {
    var attributeValue = '';

    if ((product) && (attributeID)) {
        var attribute = product.variationModel.getProductVariationAttribute(attributeID);
        if ((attribute)) {
            attributeValue = product.variationModel.getVariationValue(product, attribute);
            attributeValue = (attributeValue) ? attributeValue.getValue() : '';
        }
    }

    return attributeValue;
}

/**
 * Gets details for a single item. Called below as we loop through each item on an order
 * @param {boolean} isLastQuantity - If true, then check for special rounding scenarios (remainder)
 * @param {Object} productLineItem - Product line item from order item
 * @param {number} totalQuantity - Total quantity for this line item
 * @param {Object} shippingMethodList - Shipping methods for this item
 * @returns {Object} Full JSON needed by Deck OMS for this item
 */
function getSingleOrderItemDetails(isLastQuantity, productLineItem, totalQuantity, shippingMethodList) {
    var lineNetPrice = productLineItem.netPrice.value;
    var lineGrossPrice = productLineItem.grossPrice.value;
    var lineTax = productLineItem.tax.value;

    // Check for product options, and add to value of product if exist
    for (var optionItemIndex = 0; optionItemIndex < productLineItem.optionProductLineItems.length; optionItemIndex++) {
        lineNetPrice += productLineItem.optionProductLineItems[optionItemIndex].netPrice;
        lineGrossPrice += productLineItem.optionProductLineItems[optionItemIndex].grossPrice;
        lineTax += productLineItem.optionProductLineItems[optionItemIndex].adjustedTax.decimalValue;
    }

    var unitNetPrice = Number(getCurrency(lineNetPrice / totalQuantity));
    var unitGrossPrice = Number(getCurrency(lineGrossPrice / totalQuantity));

    // fix for tax rounding issues...just use net vs gross to calculate
    var initialUnitTax = unitGrossPrice - unitNetPrice;

    var unitTax = Number(getCurrency(initialUnitTax));

    /* Demandware passes values for total quantity, for example:
                 adjustedGross     =    137.59
                adjustedNetPr    =    116.98
                adjustedPrice    =    116.98
                adjustedTax        =    7.61
                basePrice        =    64.99
                grossPrice        =    137.59
                netPrice        =    129.98
                price            =    129.98
                proratedPrice    =    106.98
                tax                =    7.61
      When we divide by quantity, the sum of items may not equal total value
      due to rounding errors. So apply any difference to the last item.
     */
    if (isLastQuantity) {
        if ((totalQuantity * unitNetPrice) !== lineNetPrice) {
            unitNetPrice += lineNetPrice - (totalQuantity * unitNetPrice);
        }

        if ((totalQuantity * unitGrossPrice) !== lineGrossPrice) {
            unitGrossPrice += lineGrossPrice - (totalQuantity * unitGrossPrice);
        }

        if ((totalQuantity * unitTax) !== lineTax) {
            unitTax += lineTax - (totalQuantity * unitTax);
        }
    }

    var product = productLineItem.getProduct();
    var productImage = (product) ? product.getImage('large', 0) : null;

    var itemData = {
        SKU: productLineItem.productID,
        GTIN: productLineItem.productID,
        Custom1: (product) && (product.custom.color) ? product.custom.color : '',
        NetPrice: getCurrency(unitNetPrice).toString(),
        GrossPrice: getCurrency(unitGrossPrice).toString(),
        ImageURL: (productImage) ? productImage.httpsURL.toString() : '',
        StyleNumber: (product) && (product.name) ? product.name : '',
        ProductSize: getProductAttributeValue(product, 'size'),
        GiftMessage: (giftMessage) ? giftMessage.replace(/\\u[\dA-Fa-f]{4}|[\\\\/\b\f\n\r\t]/g, '') : '',
        ShippingReferenceID: getShippingReferenceId(shippingMethodList, productLineItem.shipment.shipmentNo),
        OrderItemTaxes: [{ TaxType: 'USSalesTotal', Amount: getCurrency(unitTax).toString() }],
        ItemAdjustments: [],
        Extended: []
        /*
        Note to site development team: Check with your Deck Commerce team to determine what values should be passed
        into custom data placeholders. Custom1-5 are pass through data fields that are displayed
        to customer service to give them extra details about the products, but then are also
        values that can be included in emails to the customer and also passed down to the
        warehouse or ERP systems.

            Custom1:'',
            Custom2:'',
            Custom3:'',
            Custom4:'',
            Custom5:''
        */
    };

    // Handle item level discounts
    for (var adjustIndex = 0; adjustIndex < productLineItem.priceAdjustments.length; adjustIndex++) {
        var netItemAdjustment = -1.0 * productLineItem.priceAdjustments[adjustIndex].netPrice.value;
        var grossItemAdjustment = -1.0 * productLineItem.priceAdjustments[adjustIndex].grossPrice.value;

        if (grossItemAdjustment === 0) {
            // Discounts only come across with net adjustment, but OMS wants it the same in both
            grossItemAdjustment = netItemAdjustment;
        }

        var itemCouponCode = '';
        if (productLineItem.priceAdjustments[adjustIndex].couponLineItem != null && productLineItem.priceAdjustments[adjustIndex].couponLineItem.applied) {
            itemCouponCode = productLineItem.priceAdjustments[adjustIndex].couponLineItem.couponCode;
        }

        var unitnetItemAdjustment = getCurrency(netItemAdjustment / totalQuantity);
        var unitgrossItemAdjustment = getCurrency(grossItemAdjustment / totalQuantity);

        if (isLastQuantity) {
            if ((totalQuantity * unitnetItemAdjustment) !== getCurrency(netItemAdjustment)) {
                unitnetItemAdjustment += getCurrency(netItemAdjustment) - (totalQuantity * unitnetItemAdjustment);
            }

            if ((totalQuantity * unitgrossItemAdjustment) !== getCurrency(grossItemAdjustment)) {
                unitgrossItemAdjustment += getCurrency(grossItemAdjustment) - (totalQuantity * unitgrossItemAdjustment);
            }
        }


        itemData.ItemAdjustments.push({
            CampaignID: productLineItem.priceAdjustments[adjustIndex].campaignID,
            PromotionID: productLineItem.priceAdjustments[adjustIndex].promotionID,
            NetPrice: getCurrency(unitnetItemAdjustment).toString(),
            GrossPrice: getCurrency(unitgrossItemAdjustment).toString(),
            DiscountText: productLineItem.priceAdjustments[adjustIndex].lineItemText,
            CouponCode: itemCouponCode,
            AdjustmentType: 'ItemDiscount'
        });
    }


    // Check for product options, and add to value of product promotion if exist
    for (var c = 0; c < productLineItem.optionProductLineItems.length; c++) {
        for (var optionIndex = 0; optionIndex < productLineItem.optionProductLineItems[c].priceAdjustments.length; optionIndex++) {
            var netAdjustment = -1.0 * productLineItem.optionProductLineItems[c].priceAdjustments[optionIndex].netPrice.value;
            var grossAdjustment = -1.0 * productLineItem.optionProductLineItems[c].priceAdjustments[optionIndex].grossPrice.value;

            if (grossAdjustment === 0) {
                // Discounts sometimes come across with net adjustment, but OMS wants it the same in both
                grossAdjustment = netAdjustment;
            }

            var optionCouponCode = '';
            if (productLineItem.optionProductLineItems[c].priceAdjustments[optionIndex].couponLineItem != null && productLineItem.optionProductLineItems[c].priceAdjustments[optionIndex].couponLineItem.applied) {
                optionCouponCode = productLineItem.optionProductLineItems[c].priceAdjustments[optionIndex].couponLineItem.couponCode;
            }

            var unitNetAdjustment = getCurrency(netAdjustment / totalQuantity);
            var unitGrossAdjustment = getCurrency(grossAdjustment / totalQuantity);

            if (isLastQuantity) {
                if ((totalQuantity * unitNetAdjustment) !== getCurrency(netAdjustment)) {
                    unitNetAdjustment += getCurrency(netAdjustment) - (totalQuantity * unitNetAdjustment);
                }

                if ((totalQuantity * unitGrossAdjustment) !== getCurrency(grossAdjustment)) {
                    unitGrossAdjustment += getCurrency(grossAdjustment) - (totalQuantity * unitGrossAdjustment);
                }
            }

            var existingDiscount = doesCampaignAlreadyExist(itemData.ItemAdjustments,
                                        productLineItem.optionProductLineItems[c].priceAdjustments[optionIndex].campaignID,
                                        productLineItem.optionProductLineItems[c].priceAdjustments[optionIndex].promotionID);


            if (existingDiscount >= 0) {
                itemData.ItemAdjustments[existingDiscount].NetPrice += getCurrency(unitNetAdjustment);
                itemData.ItemAdjustments[existingDiscount].GrossPrice += getCurrency(unitGrossAdjustment);
            } else {
                itemData.ItemAdjustments.push({
                    CampaignID: productLineItem.optionProductLineItems[c].priceAdjustments[optionIndex].campaignID,
                    PromotionID: productLineItem.optionProductLineItems[c].priceAdjustments[optionIndex].promotionID,
                    NetPrice: getCurrency(unitNetAdjustment).toString(),
                    GrossPrice: getCurrency(unitGrossAdjustment).toString(),
                    DiscountText: productLineItem.optionProductLineItems[c].priceAdjustments[optionIndex].lineItemText,
                    CouponCode: optionCouponCode,
                    AdjustmentType: 'ItemDiscount'
                });
            }
        }
    }

    // Handle line item prorated discount
    var liPriceAdjustmentsPrices = productLineItem.getProratedPriceAdjustmentPrices();
    var liPriceAdjustments = liPriceAdjustmentsPrices.keySet();

    for (var i = 0; i < liPriceAdjustments.size(); i++) {
        var liPriceAdjustment = liPriceAdjustments[i];

        if ((liPriceAdjustment.promotion) && liPriceAdjustment.promotion.promotionClass.equals(PROMOTION_CLASS_ORDER)) {
            var couponCode = '';

            if ((liPriceAdjustment.couponLineItem) && liPriceAdjustment.couponLineItem.applied) {
                couponCode = liPriceAdjustment.couponLineItem.couponCode;
            }

            var totalProratedAmount = getCurrency(-1.0 * liPriceAdjustmentsPrices.get(liPriceAdjustment).value);
            var unitProratedAmount = getCurrency(totalProratedAmount / totalQuantity);
            if (isLastQuantity) {
                if ((totalQuantity * unitProratedAmount) !== totalProratedAmount) {
                    var newUPA = Number(unitProratedAmount) + Number(totalProratedAmount - (totalQuantity * unitProratedAmount));
                    unitProratedAmount = getCurrency(newUPA);
                }
            }

            if (doesCampaignAlreadyExist(itemData.ItemAdjustments, liPriceAdjustment.campaignID,
                liPriceAdjustment.promotionID) === -1) {
                itemData.ItemAdjustments.push({
                    CampaignID: liPriceAdjustment.campaignID,
                    PromotionID: liPriceAdjustment.promotionID,
                    NetPrice: unitProratedAmount.toString(),
                    GrossPrice: unitProratedAmount.toString(),
                    DiscountText: liPriceAdjustment.lineItemText,
                    CouponCode: couponCode,
                    AdjustmentType: 'ItemProratedDiscount'
                });
            }
        }
    }

    return itemData;
}

/**
 * Get order item details
 * @param {dw.order.Order} order - The order being exported
 * @param {string} shippingMethodList - List of shipping methods for this item
 * @returns {Object} JSON object representing the order item details to be passed to OMS
*/
function getOrderItems(order, shippingMethodList) {
    try {
        var items = [];
        var productLineItems = order.getAllProductLineItems().iterator();
        while (productLineItems.hasNext()) {
            var productLineItem = productLineItems.next();
            if (!productLineItem.optionProductLineItem) {
                var quantity = productLineItem.quantity.value;
                for (var c = quantity; c > 0; c--) {
                    items.push(
                            getSingleOrderItemDetails(c === 1, productLineItem, quantity, shippingMethodList)
                        );
                }
            }
        }
        return items;
    } catch (error) {
        Logger.error('DC Order Import - exception in getOrderItems: ' + error.message + error.stack);
        throw error;
    }
}

/**
 * Helper function to map payment/transaction attributes to corresponding placeholders in OMS. Due to custom payment
 * implementations, rely on a JSON mapping object to help map which Demandware attributes map to which OMS field. If
 * a mapping has multiple attributes (separated by comma) then combine those into one field, separated by slashes - this
 * is commonly used for AVS/CVV2 results returned by payment processors.
 * @param {string} attributeList - The list of attribute names to parse
 * @param {Object} transaction - The authorization transaction for this payment
 * @param {Object} payment - The order payment being described
 * @returns {string} Payment attribute value for given transaction/payment
 */
function getAttributeMappingResult(attributeList, transaction, payment) {
    var attributeListArr = attributeList.split(',');
    var result = '';
    for (var c = 0; c < attributeListArr.length; c++) {
        if (result !== '') {
            result += '/';
        }

        switch (attributeListArr[c]) {
            case 'transactionID':
                result += transaction.transactionID;
                break;
            case 'expiration':
                result += payment.creditCardExpirationMonth.toString() + '/' + payment.creditCardExpirationYear.toString();
                break;
            case 'creditCardType':
                result += payment.creditCardType;
                break;
            case 'creditCardNumberLastDigits':
                result += payment.creditCardNumberLastDigits;
                break;
            case 'paypalToken':
                result += payment.custom.paypalToken;
                break;
            case 'paypalPayerId':
                result += payment.custom.paypalPayerID;
                break;
            case 'requestToken':
                result += transaction.custom.requestToken;
                break;
            default:
                if (attributeListArr[c] in transaction.custom) {
                    result += transaction.getCustom()[attributeListArr[c]];
                }
                break;
        }
    }
    return result;
}

/**
 * Get order payments and their associated transaction details to pass to OMS
 * @param {dw.order.Order} order - The order being exported
 * @returns {Object} JSON object representing the order payments
*/
function getOrderPayments(order) {
    try {
        var paymentMappings = JSON.parse(Site.getCurrent().getCustomPreferenceValue('DeckCommercePaymentMappings'));

        var data = [];
        var paymentInstruments = order.getPaymentInstruments();
        for (var p = 0; p < paymentInstruments.length; p++) {
            var transaction = paymentInstruments[p].getPaymentTransaction();
            var processor = transaction.getPaymentProcessor().ID;

            for (var m = 0; m < paymentMappings.Mappings.length; m++) {
                if (paymentMappings.Mappings[m].ProcessorType === processor) {
                    var orderPayment = {
                        PaymentProcessorSubTypeName: paymentMappings.Mappings[m].OMSProcessorType,
                        Generic1: getAttributeMappingResult(paymentMappings.Mappings[m].PaymentAttribute1, transaction, paymentInstruments[p]),
                        Generic2: getAttributeMappingResult(paymentMappings.Mappings[m].PaymentAttribute2, transaction, paymentInstruments[p]),
                        Generic3: getAttributeMappingResult(paymentMappings.Mappings[m].PaymentAttribute3, transaction, paymentInstruments[p]),
                        Generic4: getAttributeMappingResult(paymentMappings.Mappings[m].PaymentAttribute4, transaction, paymentInstruments[p]),
                        Generic5: getAttributeMappingResult(paymentMappings.Mappings[m].PaymentAttribute5, transaction, paymentInstruments[p]),
                        AuthorizedAmount: transaction.amount.value,
                        PaymentToken: getAttributeMappingResult(paymentMappings.Mappings[m].PaymentToken, transaction, paymentInstruments[p]),
                        OrderTransactions: [{
                            Generic1: getAttributeMappingResult(paymentMappings.Mappings[m].TransactionAttribute1, transaction, paymentInstruments[p]),
                            Generic2: getAttributeMappingResult(paymentMappings.Mappings[m].TransactionAttribute2, transaction, paymentInstruments[p]),
                            Generic3: getAttributeMappingResult(paymentMappings.Mappings[m].TransactionAttribute3, transaction, paymentInstruments[p]),
                            Generic4: getAttributeMappingResult(paymentMappings.Mappings[m].TransactionAttribute4, transaction, paymentInstruments[p]),
                            Generic5: getAttributeMappingResult(paymentMappings.Mappings[m].TransactionAttribute5, transaction, paymentInstruments[p]),
                            TransactionAmount: transaction.amount.value
                        }]
                    };

                    /* If payment method is DECK_COMMERCE, then this is from Agent Order
                     * Form -- need to map transaction details from custom attribute
                     * on payment instrument that is populated by Agent Order Form */
                    if (paymentInstruments[p].paymentMethod === 'DECK_COMMERCE') {
                        if ('deckCommercePaymentDetails' in paymentInstruments[p].custom) {
                            var deckAofPaymentDetails = JSON.parse(paymentInstruments[p].custom.deckCommercePaymentDetails);
                            if (deckAofPaymentDetails.PaymentMethod) {
                                orderPayment.PaymentProcessorSubTypeName = deckAofPaymentDetails.PaymentMethod;
                            }
                            if (deckAofPaymentDetails.Generics) {
                                orderPayment.OrderTransactions[0].Generic1 = deckAofPaymentDetails.Generics[0];
                                orderPayment.OrderTransactions[0].Generic2 = deckAofPaymentDetails.Generics[1];
                                orderPayment.OrderTransactions[0].Generic3 = deckAofPaymentDetails.Generics[2];
                                orderPayment.OrderTransactions[0].Generic4 = deckAofPaymentDetails.Generics[3];
                                orderPayment.OrderTransactions[0].Generic5 = deckAofPaymentDetails.Generics[4];
                            }
                        }
                    }
                    data.push(orderPayment);

                    break;
                }
            }
        }
        return data;
    } catch (error) {
        Logger.error('DC Order Import - exception in getOrderPayments: ' + error.message + error.stack);
        throw error;
    }
}

/**
 * getOrderAdjustments gets the order adjustments JSON data for the OMS model
 *
 * @param {dw.order.Order} order - The order being exported
 * @returns {Object} JSON object representing the order adjustments for OMS
 **/
function getOrderAdjustments(order) {
    var data = [];

    // Handle shipping discounts
    for (var i = 0; i < order.allShippingPriceAdjustments.length; i++) {
        var couponCode = '';
        if (order.allShippingPriceAdjustments[i].couponLineItem != null && order.allShippingPriceAdjustments[i].couponLineItem.applied) {
            couponCode = order.allShippingPriceAdjustments[i].couponLineItem.couponCode;
        }

        data.push({
            Amount: getCurrency(-1.0 * order.allShippingPriceAdjustments[i].netPrice.value).toString(),
            PromotionID: order.allShippingPriceAdjustments[i].promotionID,
            CampaignID: order.allShippingPriceAdjustments[i].campaignID,
            DiscountText: order.allShippingPriceAdjustments[i].lineItemText,
            CouponCode: couponCode,
            AdjustmentType: 'ShippingDiscount'
        });
    }

    return data;
}

/**
 * Gets the list of gift cards that a customer has purchased on this order.
 * NOTE: This is a list of gift cards being bought -- not a list of gift
 * cards that are used to pay for the order.
 * @param {dw.order.Order} order - The order object to be exported
 * @returns {Object} JSON object of gift cards
 */
function getGiftCards(order) {
    var data = [];

    var giftCerts = order.giftCertificateLineItems.iterator();
    // Handle shipping discounts
    while (giftCerts.hasNext()) {
        var gc = giftCerts.next();

        data.push({
            Id: null,
            NetPrice: gc.netPrice.value,
            GrossPrice: gc.grossPrice.value,
            BasePrice: gc.basePrice.value,
            Tax: gc.tax.value,
            TaxBasis: gc.taxBasis.value,
            LineItemText: null,
            ShipmentId: null,
            Message: gc.message,
            RecipientEmail: gc.recipientEmail,
            RecipientName: gc.recipientName,
            SenderName: gc.senderName,
            IsEGiftCard: true,
            ItemNumber: null

            /* NOTE:
               If doing physical gift cards, need to set is-egift card to false, and then
               the recipient email (as well as message potentially) would be passed as
               empty strings
            */
        });
    }

    return data;
}

/**
 * Converts a SFCC order into an object that matches the format of an OMS order
 * @param {dw.order.Order} order - Order being exported
 * @param {string} company - Company/Site Code for order being exported (from site preferences)
 * @param {string} sharedKey - Shared key for this site (from site preferences)
 * @returns {Object} JSON object of full order
*/
function getOmsOrderJson(order, company, sharedKey) {
    try {
        var timestamp = new Date().toUTCString();

        var shippingMethods = getShippingMethods(order);

        var data = {
            SiteCode: company,
            VerificationKey: DeckHelper.getVerificationKey(timestamp, DeckHelper.omsApiPart, sharedKey),
            TimestampUTC: timestamp,
            OrderNumber: order.currentOrderNo,
            CustomerID: order.customerNo,
            OrderDateUTC: order.creationDate,
            ShippingMethod: order.shipments[0].shippingMethodID,
            OrderSource: order.createdBy,
            BillingAddress: {
                FirstName: order.billingAddress.firstName,
                LastName: order.billingAddress.lastName,
                Address1: order.billingAddress.address1,
                Address2: order.billingAddress.address2,
                City: order.billingAddress.city,
                Province: order.billingAddress.stateCode,
                PostalCode: order.billingAddress.postalCode,
                Country: order.billingAddress.countryCode.value.toString(),
                Email: order.customerEmail,
                Phone: order.billingAddress.phone,
                Salutation: order.billingAddress.salutation,
                CompanyName: order.billingAddress.companyName,
                Suffix: order.billingAddress.suffix
            },
            ShippingAddress: {
                FirstName: order.shipments[0].shippingAddress.firstName,
                LastName: order.shipments[0].shippingAddress.lastName,
                Address1: order.shipments[0].shippingAddress.address1,
                Address2: order.shipments[0].shippingAddress.address2,
                City: order.shipments[0].shippingAddress.city,
                Province: order.shipments[0].shippingAddress.stateCode,
                PostalCode: order.shipments[0].shippingAddress.postalCode,
                Country: order.shipments[0].shippingAddress.countryCode.value.toString(),
                Email: order.customerEmail,
                Phone: order.shipments[0].shippingAddress.phone,
                Salutation: order.shipments[0].shippingAddress.salutation,
                CompanyName: order.shipments[0].shippingAddress.companyName,
                Suffix: order.shipments[0].shippingAddress.suffix
            },
            MerchandiseNetTotal: getCurrency(order.merchandizeTotalNetPrice.value + order.giftCertificateTotalNetPrice.value).toString(),
            MerchandiseGrossTotal: getCurrency(order.merchandizeTotalGrossPrice.value + order.giftCertificateTotalGrossPrice.value).toString(),
            ShippingNetTotal: getCurrency(order.shippingTotalNetPrice.value).toString(),
            ShippingGrossTotal: getCurrency(order.shippingTotalGrossPrice.value).toString(),
            OrderNetTotal: getCurrency(order.totalNetPrice.value).toString(),
            AdjustedMerchandiseNetTotal: getCurrency(order.adjustedMerchandizeTotalNetPrice.value + order.giftCertificateTotalNetPrice.value).toString(),
            AdjustedMerchandiseGrossTotal: getCurrency(order.adjustedMerchandizeTotalGrossPrice.value + order.giftCertificateTotalGrossPrice.value).toString(),
            AdjustedShippingNetTotal: getCurrency(order.adjustedShippingTotalNetPrice.value).toString(),
            AdjustedShippingGrossTotal: getCurrency(order.adjustedShippingTotalGrossPrice.value).toString(),
            OrderGrossTotal: getCurrency(order.totalGrossPrice.value).toString(),
            CustomerOrderLocale: order.customerLocaleID,
            SourceIp: order.remoteHost,
            OrderTaxes: getOrderTaxes(order),
            OrderItems: getOrderItems(order, shippingMethods),
            OrderPayments: getOrderPayments(order),
            OrderAdjustments: getOrderAdjustments(order),
            GiftCards: getGiftCards(order),
            ShippingMethods: shippingMethods

/* Note to site development team: If using AVS and the customer selects to override the suggested address, it is recommended
   to capture this in a custom field on the order or address, so it can be passed to OMS. This way
   this information can be displayed in OMS to customer service. (This can also be passed along to any
   grading system in place). Sample code shown below on how to pass this:*/
//            CustomAttributes : {
//                'shipping address verified': order.shipments[0].shippingAddress.custom['shippingAddressVerified']
//            }
        };

        return data;
    } catch (error) {
        var err = error;
        Logger.error('DC Order Import - exception in getOmsOrderJson: ' + err.message + err.stack);
        throw error;
    }
}


/**
 * Does all the work to export an order by calling all the various
 * methods below to build up the order JSON object.
 * @param {dw.order.Order} dwOrder - The order object to be exported
 */
function exportOrder(dwOrder) {
    try {
        dwOrder.custom.deckCommerceLastExport = new Date();
        var company = Site.getCurrent().getCustomPreferenceValue('DeckCommerceCompanyCode');
        var sharedKey = Site.getCurrent().getCustomPreferenceValue('DeckCommerceSharedApiKey');
        giftMessage = dwOrder.defaultShipment.giftMessage;

        var omsOrder = getOmsOrderJson(dwOrder, company, sharedKey);
        var jsonOrder = JSON.stringify(omsOrder);
        var jsonOrderRequest = jsonOrder;

        var serviceResponse = DeckOrderExportHelper.ServiceExport.call(jsonOrderRequest);

        if (serviceResponse.ok) {
            Logger.info('DC Order export - success: ' + dwOrder.orderNo);
            dwOrder.setExportStatus(EXPORT_STATUS_EXPORTED);
        } else {
            handleFailedExport(dwOrder);
            Logger.error('DC Order export - exception: ' + serviceResponse.error + ':' + serviceResponse.msg + ':' + serviceResponse.errorMessage);
            throw new Error('Error in order export API request');
        }
    } catch (error) {
        var err = error;
        Logger.error('DC Order Export - exception: ' + err.message + err.stack);
        if (dwOrder != null) {
            handleFailedExport(dwOrder);
        }
        throw error;
    }
}

module.exports = {
    exportOrder: exportOrder
};
