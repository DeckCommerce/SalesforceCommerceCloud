/**
* This script gets order history by querying OMS directly. This is used by both guest
* order history lookup as well as order history within a user's account. In the guest order
* history scenario, order number and postal code are required as well as a third piece of
* information. This third piece can either be customer's last name or email address. A boolean
* flag determines which search mode is being used.
*/

/* eslint no-param-reassign: ["error", { "props": true, "ignorePropertyModificationsFor": ["pagingObject"] }] */

var Logger = require('dw/system/Logger').getLogger('Deck', 'OrderHistory');
var formatMoney = require('*/cartridge/scripts/util/formatting').formatCurrency;
var DeckOrderHistoryHelper = require('*/cartridge/scripts/service/common/OrderHistoryHttpService');
var ArrayList = require('dw/util/ArrayList');

/** This is needed to convert the returned list into a SFCC recognized ArrayList object
 * @param {Object} orderList - List of orders as returned by Deck API
 * @returns {Object} List of orders in ArrayList
 */
function convertOrderList(orderList) {
    try {
        var orders = new ArrayList();
        for (var i = 0; i < orderList.length; i++) {
            orders.push(orderList[i]);
        }
        return orders;
    } catch (error) {
        var err = error;
        Logger.error('DC Order history detail - exception: ' + err.message + err.stack);
        throw error;
    }
}

/**
 * Get order history from the Deck Commerce Order History API
 * Order history can be queried by order number directly, or by the customer number.
 * Note that validation in order to view the order is handled by the storefront.
 * By this, we mean if a guest (unregistered user) wants to view their order history,
 * the API simply requires order number. It is up to the storefront to validate that
 * this user is allowed to view the order by checking fields like email, zip code, etc.
 * Default logic for this is included in the code below, but could be modified if the
 * business has different requirements or wants to use different fields.
 * @param {string} OrderNumber - Order number to search by (optional)
 * @param {string} PostalCode - Used to validate authorized user by comparing postal code
 * @param {boolean} SearchByEmail - If true, then search value matches email, else matches last name
 * @param {string} SearchValue - Value that matches either email or name (used to verification purposes)
 * @param {string} CustomerNumber - Customer number used for registered user order history
 * @param {boolean} IsAgentRequest - If true, allows order history to return without extra validation
 * @param {string} CurrencyCode - Currency code for site being rendered
 * @param {Object} pagingObject - Paging object with current page, page size, etc.
 * @returns {Object} List of orders that match search criteria
 */
function getOrderHistory(OrderNumber, PostalCode, SearchByEmail, SearchValue, CustomerNumber, IsAgentRequest, CurrencyCode, pagingObject) {
    try {
        var pageSize = 10;
        var currentPage = 1;
        if (pagingObject) {
            if (!isNaN(pagingObject.pageSize)) {
                pageSize = pagingObject.pageSize;
            }
            if (!isNaN(pagingObject.currentPage)) {
                currentPage = pagingObject.currentPage;
            }
        }

        var serviceResponse = DeckOrderHistoryHelper.ServiceExport.call(OrderNumber, CustomerNumber, pageSize, currentPage);

        if (!serviceResponse.ok) {
            Logger.error('DC Order history - exception: ' + serviceResponse.status + ':' + serviceResponse.errorMessage);
            return new ArrayList();
        }

        var orderList = serviceResponse.object;

        // Abort if non-success response code
        if (orderList.ResponseCode !== 0) {
            Logger.error('DC Order history - exception: order response code = ' + orderList.responseCode);
            // Return empty array, so order history paging has something to work with
            return new ArrayList();
        }

        // No orders found
        if (orderList.OrderDetails.length === 0) {
            Logger.error('DC Order history - exception: no orders found');
            // Return empty array, so order history paging has something to work with
            return new ArrayList();
        }

        if (pagingObject) {
            pagingObject.numberOfPages = orderList.TotalPages;
        }

        for (var c = 0; c < orderList.OrderDetails.length; c++) {
            var totalQuantity = 0;
            for (var j = 0; j < orderList.OrderDetails[c].Items.length; j++) {
                orderList.OrderDetails[c].Items[j].TotalDisplayPrice = formatMoney(orderList.OrderDetails[c].Items[j].Quantity * orderList.OrderDetails[c].Items[j].DisplayPrice, CurrencyCode);
                orderList.OrderDetails[c].Items[j].DisplayPrice = formatMoney(orderList.OrderDetails[c].Items[j].DisplayPrice, CurrencyCode);
                totalQuantity += orderList.OrderDetails[c].Items[j].Quantity;
            }
            for (var k = 0; k < orderList.OrderDetails[c].Payments.length; k++) {
                orderList.OrderDetails[c].Payments[k].Amount = formatMoney(orderList.OrderDetails[c].Payments[k].Amount, CurrencyCode);
            }
            orderList.OrderDetails[c].SimpleTotals.SubTotal = formatMoney(orderList.OrderDetails[c].SimpleTotals.SubTotal, CurrencyCode);
            orderList.OrderDetails[c].SimpleTotals.Discount = formatMoney(orderList.OrderDetails[c].SimpleTotals.Discount, CurrencyCode);
            orderList.OrderDetails[c].SimpleTotals.Shipping = formatMoney(orderList.OrderDetails[c].SimpleTotals.Shipping, CurrencyCode);
            orderList.OrderDetails[c].SimpleTotals.Tax = formatMoney(orderList.OrderDetails[c].SimpleTotals.Tax, CurrencyCode);
            orderList.OrderDetails[c].SimpleTotals.Total = formatMoney(orderList.OrderDetails[c].SimpleTotals.Total, CurrencyCode);
            orderList.OrderDetails[c].TotalQuantity = totalQuantity;
        }

        var returnedOrders = convertOrderList(orderList.OrderDetails);
        // If being called from CS-Suite, or if this is part of customer account request, no extra validation needed
        if (IsAgentRequest || (CustomerNumber)) {
            Logger.info('DC Order history API - success: returning ' + returnedOrders.size() + ' orders.');
            return returnedOrders;
        }

        // If being called from login page with postal code entered
        if (PostalCode) {
            /* Validate either email address or customer last name, as well as postal code. For postal code, only look
             * at first 5 for US, and remove any spaces (non alphanumeric) for international. */
            var postalCode = PostalCode;
            if (postalCode.length > 6 && postalCode.substring(5, 6) === '-') {
                postalCode = postalCode.substring(0, 5);
            }
            postalCode = postalCode.replace(/\W/g, '').toLowerCase();

            var billingPostal = orderList.OrderDetails[0].CustomerAddress.PostalCode.replace(/\W/g, '').toLowerCase();
            var shippingPostal = orderList.OrderDetails[0].ShipAddress.PostalCode.replace(/\W/g, '').toLowerCase();

            if (billingPostal.substring(0, postalCode.length) !== postalCode && shippingPostal.substring(0, postalCode.length) !== postalCode) {
                Logger.error('DC Order history - exception: postal code entered does not match postal code on order');
                // postal code does not match shipping or billing postal code
                // Return empty array, so order history paging has something to work with
                return new ArrayList();
            }
        }

        if (SearchByEmail) {
            // validate email matches
            if (SearchValue.toLowerCase() !== orderList.OrderDetails[0].EmailAddress.toLowerCase()) {
                Logger.error('DC Order history - exception: email entered does not match email on order');
                // Return empty array, so order history paging has something to work with
                return new ArrayList();
            }
        } else if (SearchValue) {
            // validate last name matches
            if (SearchValue.toLowerCase() !== orderList.OrderDetails[0].CustomerAddress.LastName.toLowerCase() &&
                SearchValue.toLowerCase() !== orderList.OrderDetails[0].ShipAddress.LastName.toLowerCase()) {
                Logger.error('DC Order history - exception: Last Name entered does not match Last Name on order');
                // Return empty array, so order history paging has something to work with
                return new ArrayList();
            }
        }

        Logger.info('DC Order history API - success: returning ' + returnedOrders.size() + ' orders.');
        return returnedOrders;
    } catch (error) {
        var err = error;
        Logger.error('DC Order history detail - exception: ' + err.message + err.stack);
        throw error;
    }
}

module.exports = {
    getOrderHistory: getOrderHistory
};
