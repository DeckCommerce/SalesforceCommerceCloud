'use strict';
var page = module.superModule;
var server = require('server');
server.extend(page);

/**
 * After running normal place order logic, pass order to Deck OMS API
 */
server.append(
    'PlaceOrder',
    server.middleware.https,
    function (req, res, next) {
        var OrderMgr = require('dw/order/OrderMgr');
        var viewData = res.getViewData();
        if (!viewData.error) {
            var OrderExportAPI = require('*/cartridge/scripts/service/request/orderExportRequest');
            var Transaction = require('dw/system/Transaction');
            Transaction.wrap(function () {
                OrderExportAPI.exportOrder(OrderMgr.getOrder(viewData.orderID, viewData.orderToken));
            });
        }
        return next();
    }
);

module.exports = server.exports();
