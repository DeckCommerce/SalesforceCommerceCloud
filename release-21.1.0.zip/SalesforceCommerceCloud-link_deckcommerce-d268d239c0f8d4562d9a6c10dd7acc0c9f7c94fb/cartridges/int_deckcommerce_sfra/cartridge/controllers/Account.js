'use strict';

var page = module.superModule;
var server = require('server');
server.extend(page);

var userLoggedIn = require('*/cartridge/scripts/middleware/userLoggedIn');
var consentTracking = require('*/cartridge/scripts/middleware/consentTracking');

/* Deck Commerce API Includes */
var OrderHistoryAPI = require('*/cartridge/scripts/service/request/orderHistoryRequest');

/**
 * Before running normal Account-Show functionality, get order history from Deck OMS and
 * save this data to be leveraged by ISML later when displaying order history.
 */
server.prepend(
		'Show',
		server.middleware.https,
		userLoggedIn.validateLoggedIn,
		consentTracking.consent,
        function (req, res, next) {
            var customerOrders = OrderHistoryAPI.getOrderHistory(null, null, null, null, req.currentCustomer.profile.customerNo, null, req.session.currency.currencyCode);
            res.setViewData({
                OmsLastOrder: customerOrders && customerOrders.length > 0 ? customerOrders[0] : null
            });
            next();
        }
);

module.exports = server.exports();
