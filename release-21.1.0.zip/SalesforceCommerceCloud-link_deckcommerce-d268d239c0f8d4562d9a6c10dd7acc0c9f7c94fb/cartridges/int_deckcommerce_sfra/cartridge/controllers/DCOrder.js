'use strict';

var server = require('server');
var Resource = require('dw/web/Resource');
var URLUtils = require('dw/web/URLUtils');
var csrfProtection = require('*/cartridge/scripts/middleware/csrf');
var userLoggedIn = require('*/cartridge/scripts/middleware/userLoggedIn');
var consentTracking = require('*/cartridge/scripts/middleware/consentTracking');

/* Deck Commerce API Includes */
var OrderHistoryAPI = require('*/cartridge/scripts/service/request/orderHistoryRequest');


/**
 * Overrides the "track you order" method used by guest (non-logged in) users. Call the
 * Deck Commerce order history API to retrieve data.
 */
server.get(
    'Track',
    consentTracking.consent,
    server.middleware.https,
    csrfProtection.validateRequest,
    csrfProtection.generateToken,
    function (req, res, next) {
        var order;
        var validForm = true;
        var profileForm = server.forms.getForm('profile');
        profileForm.clear();

        if (req.querystring.trackOrderEmail
            && req.querystring.trackOrderPostal
            && req.querystring.trackOrderNumber) {
            var pagingObject = {
                currentPage: 1,
                numberOfPages: 0,
                pageSize: 1
            };

            var orders = OrderHistoryAPI.getOrderHistory(req.querystring.trackOrderNumber, null, null, null, null, null, req.session.currency.currencyCode, pagingObject);
            if (orders.length > 0) {
                order = orders[0];
            }
        } else {
            validForm = false;
        }

        if (!order) {
            res.render('/account/login', {
                navTabValue: 'login',
                orderTrackFormError: validForm,
                profileForm: profileForm,
                userName: ''
            });
            next();
        } else {
            // check the email and postal code of the form
            if (req.querystring.trackOrderEmail.toLowerCase()
                    !== order.EmailAddress.toLowerCase()) {
                validForm = false;
            }

            if (req.querystring.trackOrderPostal
                !== order.CustomerAddress.PostalCode) {
                validForm = false;
            }

            if (validForm) {
                var exitLinkText;
                var exitLinkUrl;

                exitLinkText = !req.currentCustomer.profile
                    ? Resource.msg('link.continue.shop', 'order', null)
                    : Resource.msg('link.orderdetails.myaccount', 'account', null);

                exitLinkUrl = !req.currentCustomer.profile
                    ? URLUtils.url('Home-Show')
                    : URLUtils.https('Account-Show');

                res.render('account/orderDetails', {
                    order: order,
                    exitLinkText: exitLinkText,
                    exitLinkUrl: exitLinkUrl
                });
            } else {
                res.render('/account/login', {
                    navTabValue: 'login',
                    profileForm: profileForm,
                    orderTrackFormError: !validForm,
                    userName: ''
                });
            }

            next();
        }
    }
);

/**
 * Replaces the Details method of the order history functionality to get the
 * data from Deck Commerce API instead.
 */
server.get(
	'Details',
	consentTracking.consent,
	server.middleware.https,
	userLoggedIn.validateLoggedIn,
    function (req, res, next) {
        var pagingObject = {
            currentPage: 1,
            numberOfPages: 0,
            pageSize: 1
        };
        var orders = OrderHistoryAPI.getOrderHistory(req.querystring.orderID, null, null, null, null, null, req.session.currency.currencyCode, pagingObject);
        var order = orders[0];
        var orderCustomerNo = req.currentCustomer.profile.customerNo;
        var currentCustomerNo = order.CustomerID;
        var breadcrumbs = [
            {
                htmlValue: Resource.msg('global.home', 'common', null),
                url: URLUtils.home().toString()
            },
            {
                htmlValue: Resource.msg('page.title.myaccount', 'account', null),
                url: URLUtils.url('Account-Show').toString()
            },
            {
                htmlValue: Resource.msg('label.orderhistory', 'account', null),
                url: URLUtils.url('DCOrder-History').toString()
            }
        ];

        if (order && orderCustomerNo === currentCustomerNo) {
            var exitLinkText = Resource.msg('link.orderdetails.orderhistory', 'account', null);
            var exitLinkUrl =
                URLUtils.https('DCOrder-History', 'orderFilter', req.querystring.orderFilter);
            res.render('account/orderDetails', {
                order: order,
                exitLinkText: exitLinkText,
                exitLinkUrl: exitLinkUrl,
                breadcrumbs: breadcrumbs
            });
        } else {
            res.redirect(URLUtils.url('Account-Show'));
        }
        next();
    }
);

/**
 * Replaces the "History" method of order history, so that instead the order history
 * for the given customer number is retrieved by searching the Deck Commerce API
 */
server.get(
	'History',
	consentTracking.consent,
	server.middleware.https,
	userLoggedIn.validateLoggedIn,
    function (req, res, next) {
        var pagingObject = {
            currentPage: 1,
            numberOfPages: 0,
            pageSize: 10
        };
        var orders = OrderHistoryAPI.getOrderHistory(null, null, null, null, req.currentCustomer.profile.customerNo, null, req.session.currency.currencyCode, pagingObject);
        var breadcrumbs = [
            {
                htmlValue: Resource.msg('global.home', 'common', null),
                url: URLUtils.home().toString()
            },
            {
                htmlValue: Resource.msg('page.title.myaccount', 'account', null),
                url: URLUtils.url('Account-Show').toString()
            }
        ];

        var filterValues = [
            {
                displayValue: Resource.msg('results.page', 'dcorderhistory', null) + ' 1',
                optionValue: URLUtils.url('DCOrder-Filtered', 'orderFilter', '1').abs().toString()
            }
        ];
        for (var c = 2; c <= pagingObject.numberOfPages; c++) {
            filterValues.push({
                displayValue: Resource.msg('results.page', 'dcorderhistory', null) + ' ' + c,
                optionValue: URLUtils.url('DCOrder-Filtered', 'orderFilter', c).abs().toString()
            });
        }


        res.render('account/order/history', {
            orders: orders,
            filterValues: filterValues,
            orderFilter: req.querystring.orderFilter,
            accountlanding: false,
            breadcrumbs: breadcrumbs
        });
        next();
    }
);

/**
 * Replaces the "Filtered" method of order history which allows paging of order history
 * for the logged in user who has more than one page of results to show.
 */
server.get(
    'Filtered',
    server.middleware.https,
    consentTracking.consent,
    userLoggedIn.validateLoggedInAjax,
    function (req, res, next) {
        var data = res.getViewData();
        if (data && !data.loggedin) {
            res.render('account/order/orderList', {
                orders: null,
                filterValues: null,
                orderFilter: null,
                accountlanding: false
            });
            return next();
        }
        var pagingObject = {
            currentPage: 1,
            numberOfPages: 0,
            pageSize: 10
        };

        var requestedPage = req.querystring.orderFilter;
        if (!isNaN(requestedPage)) {
            pagingObject.currentPage = requestedPage;
        }

        var orders = OrderHistoryAPI.getOrderHistory(null, null, null, null, req.currentCustomer.profile.customerNo, null, req.session.currency.currencyCode, pagingObject);
        var filterValues = [
            {
                displayValue: Resource.msg('results.page', 'dcorderhistory', null) + ' 1',
                optionValue: URLUtils.url('DCOrder-Filtered', 'orderFilter', '1').abs().toString()
            }
        ];
        for (var c = 0; c < pagingObject.numberOfPages; c++) {
            filterValues.push({
                displayValue: Resource.msg('results.page', 'dcorderhistory', null) + ' ' + c,
                optionValue: URLUtils.url('DCOrder-Filtered', 'orderFilter', c).abs().toString()
            });
        }

        res.render('account/order/orderList', {
            orders: orders,
            filterValues: filterValues,
            orderFilter: req.querystring.orderFilter,
            accountlanding: false
        });
        return next();
    }
);


module.exports = server.exports();
